#ifndef _LIBTOOL_H
#define _LIBTOOL_H

/*
 * libtool.h — freestanding libtool for Linux AArch64
 * No system headers. No external dependencies.
 */

/* ── Compiler attributes ──────────────────────────────────────────── */
#define NORETURN       __attribute__((noreturn))
#define ALWAYS_INLINE  __attribute__((always_inline)) inline
#define UNUSED         __attribute__((unused))
#define WEAK           __attribute__((weak))
#define PACKED         __attribute__((packed))
#define LIKELY(x)      __builtin_expect(!!(x), 1)
#define UNLIKELY(x)    __builtin_expect(!!(x), 0)
#define NONNULL(...)   __attribute__((nonnull(__VA_ARGS__)))

/* ── Primitive types ──────────────────────────────────────────────── */
typedef unsigned char       uint8_t;
typedef unsigned short      uint16_t;
typedef unsigned int        uint32_t;
typedef unsigned long long  uint64_t;
typedef signed char         int8_t;
typedef signed short        int16_t;
typedef signed int          int32_t;
typedef signed long long    int64_t;
typedef unsigned long       size_t;
typedef signed long         ssize_t;
typedef signed long         ptrdiff_t;
typedef unsigned long       uintptr_t;
typedef signed long         intptr_t;
typedef signed long         off_t;
typedef int                 pid_t;
typedef unsigned int        uid_t;
typedef unsigned int        gid_t;
typedef unsigned int        mode_t;
typedef long                time_t;

#define NULL       ((void*)0)
#define TRUE       1
#define FALSE      0
#define EOF        (-1)

/* Limits */
#define INT8_MIN    (-128)
#define INT8_MAX    127
#define INT16_MIN   (-32768)
#define INT16_MAX   32767
#define INT32_MIN   (-2147483648)
#define INT32_MAX   2147483647
#define INT64_MIN   (-9223372036854775807LL - 1)
#define INT64_MAX   9223372036854775807LL
#define UINT8_MAX   255U
#define UINT16_MAX  65535U
#define UINT32_MAX  4294967295U
#define UINT64_MAX  18446744073709551615ULL
#define SIZE_MAX    UINT64_MAX
#define INT_MAX     INT32_MAX
#define INT_MIN     INT32_MIN
#define LONG_MAX    INT64_MAX
#define LONG_MIN    INT64_MIN
#define CHAR_BIT    8

/* va_list — AArch64 uses a struct for varargs */
typedef __builtin_va_list va_list;
#define va_start(v,l)  __builtin_va_start(v,l)
#define va_end(v)      __builtin_va_end(v)
#define va_arg(v,t)    __builtin_va_arg(v,t)
#define va_copy(d,s)   __builtin_va_copy(d,s)

/* ── errno ────────────────────────────────────────────────────────── */
extern int errno;
#define EPERM    1
#define ENOENT   2
#define EINTR    4
#define EIO      5
#define EBADF    9
#define EAGAIN   11
#define ENOMEM   12
#define EACCES   13
#define EFAULT   14
#define EEXIST   17
#define EINVAL   22
#define ERANGE   34

/* ── Process ──────────────────────────────────────────────────────── */
NORETURN void  exit(int status);
NORETURN void  _exit(int status);
NORETURN void  abort(void);
int            atexit(void (*fn)(void));
pid_t          getpid(void);
pid_t          getppid(void);
uid_t          getuid(void);
gid_t          getgid(void);

/* ── File I/O ─────────────────────────────────────────────────────── */
#define O_RDONLY    0
#define O_WRONLY    1
#define O_RDWR      2
#define O_CREAT     0100
#define O_TRUNC     01000
#define O_APPEND    02000
#define O_CLOEXEC   02000000
#define AT_FDCWD    (-100)

#define SEEK_SET    0
#define SEEK_CUR    1
#define SEEK_END    2

#define STDIN_FILENO  0
#define STDOUT_FILENO 1
#define STDERR_FILENO 2

int      open(const char *path, int flags, ...);
int      close(int fd);
ssize_t  read(int fd, void *buf, size_t n);
ssize_t  write(int fd, const void *buf, size_t n);
off_t    lseek(int fd, off_t offset, int whence);
int      unlink(const char *path);
int      rename(const char *old, const char *newp);
int      mkdir(const char *path, mode_t mode);
int      rmdir(const char *path);
char    *getcwd(char *buf, size_t size);
int      chdir(const char *path);
int      dup(int fd);
int      dup2(int oldfd, int newfd);

/* ── Buffered stdio ───────────────────────────────────────────────── */
typedef struct FILE FILE;
extern FILE *stdin;
extern FILE *stdout;
extern FILE *stderr;

FILE    *fopen(const char *path, const char *mode);
int      fclose(FILE *f);
size_t   fread(void *buf, size_t size, size_t nmemb, FILE *f);
size_t   fwrite(const void *buf, size_t size, size_t nmemb, FILE *f);
int      fseek(FILE *f, long offset, int whence);
long     ftell(FILE *f);
int      fflush(FILE *f);
int      feof(FILE *f);
int      ferror(FILE *f);
int      fgetc(FILE *f);
int      fputc(int c, FILE *f);
char    *fgets(char *buf, int n, FILE *f);
int      fputs(const char *s, FILE *f);
int      fprintf(FILE *f, const char *fmt, ...);
int      printf(const char *fmt, ...);
int      puts(const char *s);
int      putchar(int c);
int      getchar(void);
int      sprintf(char *buf, const char *fmt, ...);
int      snprintf(char *buf, size_t size, const char *fmt, ...);
int      vsnprintf(char *buf, size_t size, const char *fmt, va_list ap);
int      vfprintf(FILE *f, const char *fmt, va_list ap);
int      vprintf(const char *fmt, va_list ap);
char    *asprintf_alloc(const char *fmt, ...);

void     perror(const char *s);
const char *strerror(int errnum);

/* ── Memory ───────────────────────────────────────────────────────── */
void    *malloc(size_t size);
void    *calloc(size_t nmemb, size_t size);
void    *realloc(void *ptr, size_t size);
void     free(void *ptr);
void    *aligned_alloc(size_t align, size_t size);

void    *memset(void *dst, int c, size_t n);
void    *memcpy(void *dst, const void *src, size_t n);
void    *memmove(void *dst, const void *src, size_t n);
int      memcmp(const void *a, const void *b, size_t n);
void    *memchr(const void *s, int c, size_t n);

/* Raw mmap */
void    *mmap(void *addr, size_t len, int prot, int flags, int fd, off_t off);
int      munmap(void *addr, size_t len);
int      mprotect(void *addr, size_t len, int prot);

/* ── Strings ──────────────────────────────────────────────────────── */
size_t   strlen(const char *s);
size_t   strnlen(const char *s, size_t max);
char    *strcpy(char *dst, const char *src);
char    *strncpy(char *dst, const char *src, size_t n);
char    *strcat(char *dst, const char *src);
char    *strncat(char *dst, const char *src, size_t n);
int      strcmp(const char *a, const char *b);
int      strncmp(const char *a, const char *b, size_t n);
int      strcasecmp(const char *a, const char *b);
int      strncasecmp(const char *a, const char *b, size_t n);
char    *strchr(const char *s, int c);
char    *strrchr(const char *s, int c);
char    *strstr(const char *hay, const char *needle);
char    *strdup(const char *s);
char    *strndup(const char *s, size_t n);
size_t   strlcpy(char *dst, const char *src, size_t dstsize);
size_t   strlcat(char *dst, const char *src, size_t dstsize);
char    *strtok_r(char *s, const char *delim, char **saveptr);

/* ── Number conversion ────────────────────────────────────────────── */
int          atoi(const char *s);
long         atol(const char *s);
long long    atoll(const char *s);
double       atof(const char *s);
long         strtol(const char *s, char **end, int base);
unsigned long strtoul(const char *s, char **end, int base);
long long    strtoll(const char *s, char **end, int base);
double       strtod(const char *s, char **end);

/* ── Character classification ─────────────────────────────────────── */
ALWAYS_INLINE int isdigit(int c)   { return (unsigned)(c-'0') < 10; }
ALWAYS_INLINE int isalpha(int c)   { return (unsigned)((c|32)-'a') < 26; }
ALWAYS_INLINE int isalnum(int c)   { return isdigit(c) || isalpha(c); }
ALWAYS_INLINE int isspace(int c)   { return c==' '||c=='\t'||c=='\n'||c=='\r'||c=='\f'||c=='\v'; }
ALWAYS_INLINE int isupper(int c)   { return (unsigned)(c-'A') < 26; }
ALWAYS_INLINE int islower(int c)   { return (unsigned)(c-'a') < 26; }
ALWAYS_INLINE int isprint(int c)   { return (unsigned)(c-' ') < 95; }
ALWAYS_INLINE int isxdigit(int c)  { return isdigit(c)||(unsigned)((c|32)-'a')<6; }
ALWAYS_INLINE int ispunct(int c)   { return isprint(c)&&!isalnum(c)&&c!=' '; }
ALWAYS_INLINE int toupper(int c)   { return islower(c) ? c-32 : c; }
ALWAYS_INLINE int tolower(int c)   { return isupper(c) ? c+32 : c; }

/* ── Math ─────────────────────────────────────────────────────────── */
#define M_PI      3.14159265358979323846
#define M_E       2.71828182845904523536
#define HUGE_VAL  __builtin_huge_val()
#define NAN       __builtin_nan("")
#define INFINITY  __builtin_inf()

double  fabs(double x);
double  floor(double x);
double  ceil(double x);
double  round(double x);
double  trunc(double x);
double  fmod(double x, double y);
double  sqrt(double x);
double  pow(double b, double e);
double  exp(double x);
double  log(double x);
double  log2(double x);
double  log10(double x);
double  sin(double x);
double  cos(double x);
double  tan(double x);
double  atan2(double y, double x);
double  fmin(double a, double b);
double  fmax(double a, double b);

ALWAYS_INLINE int   abs(int x)   { return x < 0 ? -x : x; }
ALWAYS_INLINE long  labs(long x) { return x < 0 ? -x : x; }

/* ── Sorting ──────────────────────────────────────────────────────── */
typedef int (*__cmp_fn)(const void *, const void *);
void  qsort(void *base, size_t n, size_t size, __cmp_fn cmp);
void *bsearch(const void *key, const void *base, size_t n,
              size_t size, __cmp_fn cmp);

/* ── Time ─────────────────────────────────────────────────────────── */
struct timespec { time_t tv_sec; long tv_nsec; };
struct timeval  { long tv_sec; long tv_usec; };

int    clock_gettime(int clk_id, struct timespec *ts);
int    gettimeofday(struct timeval *tv, void *tz);
int    nanosleep(const struct timespec *req, struct timespec *rem);
time_t time(time_t *t);

#define CLOCK_REALTIME  0
#define CLOCK_MONOTONIC 1

/* ── Environment ──────────────────────────────────────────────────── */
extern char **environ;
char *getenv(const char *name);

/* ── Random ───────────────────────────────────────────────────────── */
int      rand(void);
void     srand(unsigned seed);
ssize_t  getrandom(void *buf, size_t n, unsigned flags);

/* ── Assert ───────────────────────────────────────────────────────── */
NORETURN void __assert_fail(const char *expr, const char *file, int line);
#define assert(cond) \
    do { if (UNLIKELY(!(cond))) __assert_fail(#cond,__FILE__,__LINE__); } while(0)

/* ── Utility macros ───────────────────────────────────────────────── */
#define ARRAY_LEN(a)      (sizeof(a)/sizeof((a)[0]))
#define MIN(a,b)          ((a)<(b)?(a):(b))
#define MAX(a,b)          ((a)>(b)?(a):(b))
#define CLAMP(v,lo,hi)    MIN(MAX(v,lo),hi)
#define KB(n)             ((size_t)(n)*1024ULL)
#define MB(n)             ((size_t)(n)*1024ULL*1024ULL)
#define GB(n)             ((size_t)(n)*1024ULL*1024ULL*1024ULL)
#define ALIGN_UP(x,a)     (((x)+((a)-1))&~((a)-1))
#define ALIGN_DOWN(x,a)   ((x)&~((a)-1))
#define IS_POW2(x)        ((x)&&!((x)&((x)-1)))
#define OFFSETOF(T,m)     __builtin_offsetof(T,m)
#define CONTAINER_OF(p,T,m) ((T*)((char*)(p)-OFFSETOF(T,m)))
#define SWAP(T,a,b)       do{T _t=(a);(a)=(b);(b)=_t;}while(0)

/* ── Internal startup ─────────────────────────────────────────────── */
void __libc_start_main(int argc, char **argv, char **envp);

#endif /* _LIBTOOL_H */
