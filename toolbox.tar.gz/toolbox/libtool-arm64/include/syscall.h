#ifndef LIBC_SYSCALL_H
#define LIBC_SYSCALL_H

/*
 * Linux AArch64 syscall numbers (from <asm/unistd.h> for arm64)
 * These are the same across all AArch64 Linux kernels.
 */

#define SYS_io_setup            0
#define SYS_read                63
#define SYS_write               64
#define SYS_close               57
#define SYS_lseek               62
#define SYS_mmap                222
#define SYS_mprotect            226
#define SYS_munmap              215
#define SYS_brk                 214
#define SYS_rt_sigaction        134
#define SYS_rt_sigprocmask      135
#define SYS_ioctl               29
#define SYS_pipe2               59
#define SYS_dup                 23
#define SYS_dup3                24
#define SYS_getpid              172
#define SYS_getppid             173
#define SYS_getuid              174
#define SYS_getgid              176
#define SYS_geteuid             175
#define SYS_getegid             177
#define SYS_fork                1079    /* clone-based on newer kernels */
#define SYS_execve              221
#define SYS_exit                93
#define SYS_exit_group          94
#define SYS_wait4               260
#define SYS_kill                129
#define SYS_fcntl               25
#define SYS_getcwd              17
#define SYS_chdir               49
#define SYS_renameat2           276
#define SYS_mkdirat             34
#define SYS_unlinkat            35
#define SYS_nanosleep           101
#define SYS_clock_gettime       113
#define SYS_gettimeofday        169
#define SYS_getrandom           278
#define SYS_openat              56      /* AArch64 has no open(), use openat */

/* openat with AT_FDCWD behaves like open() */
#define AT_FDCWD  (-100)

/* mmap flags */
#define PROT_NONE    0x0
#define PROT_READ    0x1
#define PROT_WRITE   0x2
#define PROT_EXEC    0x4
#define MAP_SHARED   0x01
#define MAP_PRIVATE  0x02
#define MAP_FIXED    0x10
#define MAP_ANONYMOUS 0x20
#define MAP_ANON     MAP_ANONYMOUS
#define MAP_FAILED   ((void*)-1)

/* open/openat flags */
#define O_RDONLY    0
#define O_WRONLY    1
#define O_RDWR      2
#define O_CREAT     0100
#define O_TRUNC     01000
#define O_APPEND    02000
#define O_NONBLOCK  04000
#define O_CLOEXEC   02000000

/* lseek whence */
#define SEEK_SET 0
#define SEEK_CUR 1
#define SEEK_END 2

/* file descriptors */
#define STDIN_FILENO  0
#define STDOUT_FILENO 1
#define STDERR_FILENO 2

/* errno values */
#define EPERM    1
#define ENOENT   2
#define EINTR    4
#define EIO      5
#define EBADF    9
#define EAGAIN   11
#define ENOMEM   12
#define EACCES   13
#define EFAULT   14
#define EEXIST   17
#define EINVAL   22
#define ERANGE   34
#define EWOULDBLOCK EAGAIN

/* types */
typedef long            ssize_t;
typedef unsigned long   size_t;
typedef long            off_t;
typedef int             pid_t;
typedef unsigned int    uid_t;
typedef unsigned int    gid_t;
typedef unsigned int    mode_t;

/*
 * Raw syscall declarations — implemented in syscall.s
 * Arguments are all passed as long (64-bit integers on AArch64).
 */
long __syscall0(long n);
long __syscall1(long n, long a1);
long __syscall2(long n, long a1, long a2);
long __syscall3(long n, long a1, long a2, long a3);
long __syscall4(long n, long a1, long a2, long a3, long a4);
long __syscall5(long n, long a1, long a2, long a3, long a4, long a5);
long __syscall6(long n, long a1, long a2, long a3, long a4, long a5, long a6);

/* Convenience macros */
#define syscall0(n)              __syscall0((long)(n))
#define syscall1(n,a)            __syscall1((long)(n),(long)(a))
#define syscall2(n,a,b)          __syscall2((long)(n),(long)(a),(long)(b))
#define syscall3(n,a,b,c)        __syscall3((long)(n),(long)(a),(long)(b),(long)(c))
#define syscall4(n,a,b,c,d)      __syscall4((long)(n),(long)(a),(long)(b),(long)(c),(long)(d))
#define syscall5(n,a,b,c,d,e)    __syscall5((long)(n),(long)(a),(long)(b),(long)(c),(long)(d),(long)(e))
#define syscall6(n,a,b,c,d,e,f)  __syscall6((long)(n),(long)(a),(long)(b),(long)(c),(long)(d),(long)(e),(long)(f))

#endif /* LIBC_SYSCALL_H */
